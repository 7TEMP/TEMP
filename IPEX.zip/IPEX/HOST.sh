cd BASH
python HOST.py
