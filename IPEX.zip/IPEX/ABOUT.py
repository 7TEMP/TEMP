import os
os.system('cvlc ABOUT.mp3')
