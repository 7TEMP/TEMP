<!-- IPEX -->
<p align="center">
<img src="https://img.shields.io/badge/IPEX TOOL-bg?style=for-the-badge">
<p align="center">
<img src="https://img.shields.io/badge/POWERFUL TOOL V1.0-orange?style=for-the-badge">
<p align="center">
<img src="https://img.shields.io/badge/Author-A.X.E.L-red?style=flat-square">
<img src="https://img.shields.io/badge/Open%20Source-Yes-magenta?style=flat-square">
<img src="https://img.shields.io/badge/Written%20In-BASH,PYTHON,JS-cyan?style=flat-square">
</p>
<img src="https://github.com/7AXEL/IPEX/blob/main/LOGO.jpg">
</p>

<p align="center">
<img src="https://img.shields.io/badge/   DISCLAIMER   -yellow?style=for-the-badge">

### IPEX
These tools were programmed and tested by the hacker A.X.E.L and These tools are used to withdraw the ip adress and ports of websites, as well as to locate the server or the IP
### FEATURS
- HTML GPS map
- Live GPS map
### INSTALLATION
- Just, Follow steps-
```
$ git clone https://github.com/7AXEL/IPEX
```
```
$ apt-get update && upgrade
$ apt-get install python3 nodejs vlc
$ cd IPEX
$ pip install -r PIP.txt
```
### RUN
```
$ python3 MAIN.py
```
### DEPENDENCISE

**`IPEX`** requires following programs to run properly - 
- `vlc`
- `nodejs`
- `python3`
- `git`
> Supported Platform : **`Termux`**, **`Ubuntu/Debian/Kali/Parrot`**, **`Arch Linux/Manjaro`**, **`Fedora`**
<p align="center">
<img src="https://img.shields.io/badge/OTHERS TOOLS-COMINGSON-magenta?style=flat-square">
<p align="center">
<img src="https://img.shields.io/badge/A.X.E.L-brown?style=flat-square">
