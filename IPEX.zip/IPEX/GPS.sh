cd BASH
python GPS.py

