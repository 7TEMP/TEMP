from INDEX import INDEX as i
import os
os.system('clear')
h = "   "
x=f"""
{i.blue}┏━━━┓┏━┓┏━┓┏━━━┓┏┓{h}{i.red} .-~~-.{h}
{i.blue}┃┏━┓┃┗┓┗┛┏┛┃┏━━┛┃┃{h}{i.red}(_^..^_){h}
{i.blue}┃┃╋┃┃╋┗┓┏┛╋┃┗━━┓┃┃{h}{i.red}  ||||{i.cyan}🄸🄿🄴🅇{h}
{i.blue}┃┗━┛┃╋┏┛┗┓╋┃┏━━┛┃┃╋┏┓{h*2}{i.cyan}🅂🄿{h}
{i.blue}┃┏━┓┣┳┛┏┓┗┳┫┗━━┳┫┗━┛┃{h}
{i.blue}┗┛╋┗┻┻━┛┗━┻┻━━━┻┻━━━┛{h}🅰🆇🅴🅻{h*5}"""
print(x)  
