cd SERVER
node SERVER.js
